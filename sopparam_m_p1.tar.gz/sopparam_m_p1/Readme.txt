C
program can be compiled by using make command in terminal, and execute "make execute" command, and clean using "make clean" command. Input files are given in Makefile can edited from there.