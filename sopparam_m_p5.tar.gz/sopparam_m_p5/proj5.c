#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>

typedef struct {
    int profit;
    int weight;
} Item;

int n_items;
int capacity;
Item items[8];

void generate_knapsack_problem() {
    srand(time(0));
    n_items = rand() % 5 + 4;
    int total_weight = 0;

    for (int i = 0; i < n_items; ++i) {
        items[i].profit = rand() % 21 + 10;
        items[i].weight = rand() % 16 + 5;
        total_weight += items[i].weight;
    }

    capacity = (int)floor(0.6 * total_weight);
}

void save_knapsack_problem(const char *filename) {
    FILE *file = fopen(filename, "w");
    if (file == NULL) {
        printf("Error opening file for writing.\n");
        exit(1);
    }

    fprintf(file, "%d %d\n", n_items, capacity);
    for (int i = 0; i < n_items; ++i) {
        fprintf(file, "Item%d %d %d\n", i + 1, items[i].profit, items[i].weight);
    }

    fclose(file);
}

void brute_force_knapsack(const char *input_filename, const char *output_filename) {
    FILE *input_file = fopen(input_filename, "r");
    if (input_file == NULL) {
        printf("Error opening input file.\n");
        exit(1);
    }

    fscanf(input_file, "%d %d", &n_items, &capacity);

    for (int i = 0; i < n_items; ++i) {
        int item_index;
        fscanf(input_file, " Item%d %d %d", &item_index, &items[i].profit, &items[i].weight);
    }

    fclose(input_file);

    int max_profit = 0;
    int max_weight = 0;
    int best_combination = 0;

    for (int i = 1; i < (1 << n_items); ++i) {
        int profit = 0;
        int weight = 0;
        for (int j = 0; j < n_items; ++j) {
            if (i & (1 << j)) {
                profit += items[j].profit;
                weight += items[j].weight;
            }
        }

        if (weight <= capacity && profit > max_profit) {
            max_profit = profit;
            max_weight = weight;
            best_combination = i;
        }
    }

    FILE *output_file = fopen(output_filename, "w");
    if (output_file == NULL) {
        printf("Error opening output file.\n");
        exit(1);
    }

    int selected_items = 0;
    for (int i = 0; i < n_items; ++i) {
        if (best_combination & (1 << i)) {
            ++selected_items;
        }
    }

    fprintf(output_file, "%d %d %d\n", selected_items, max_profit, max_weight);

    for (int i = 0; i < n_items; ++i) {
        if (best_combination & (1 << i)) {
            fprintf(output_file, "Item%d %d %d\n", i + 1, items[i].profit, items[i].weight);
        }
    }

    fclose(output_file);
}

void save_entries(const char *filename, int n, int W, int **B) {
    FILE *file = fopen(filename, "w");
    if (file == NULL) {
        printf("Error opening file for writing.\n");
        exit(1);
    }

    for (int i = 1; i <= n; i++) {
        fprintf(file, "row%d", i);
        for (int w = 0; w <= W; w++) {
            if (B[i][w] != 0) {
                fprintf(file, " %d", w);
            }
        }
        fprintf(file, "\n");
    }

    fclose(file);
}

void dynamic_programming_refinement(int n, Item items[], int W, int *total_profit, int *total_weight, int included_items[]) {
    int i, w;
    int **B = (int **)malloc((n + 1) * sizeof(int *));
    for (i = 0; i < n + 1; i++) {
        B[i] = (int *)malloc((W + 1) * sizeof(int));
    }

    for (w = 0; w <= W; w++) {
        B[0][w] = 0;
    }

    for (i = 1; i <= n; i++) {
        for (w = 0; w <= W; w++) {
            if (items[i - 1].weight <= w) {
                int temp_profit = items[i - 1].profit + B[i - 1][w - items[i - 1].weight];
                B[i][w] = temp_profit > B[i - 1][w] ? temp_profit : B[i - 1][w];
            } else {
                B[i][w] = B[i - 1][w];
            }
        }
    }
    save_entries("entries2.txt", n, W, B);
    *total_profit = B[n][W];
    int remaining_weight = W;
    for (i = n; i > 0; i--) {
        if (B[i][remaining_weight] != B[i - 1][remaining_weight]) {
            included_items[i - 1] = 1;
            remaining_weight -= items[i - 1].weight;
        } else {
            included_items[i - 1] = 0;
        }
    }

    *total_weight = W - remaining_weight;

    for (i = 0; i < n + 1; i++) {
        free(B[i]);
    }
    free(B);
}

void save_output(const char *filename, int total_profit, int total_weight, int included_items[]) {
    FILE *file = fopen(filename, "w");
    if (file == NULL) {
        printf("Error opening file for writing.\n");
        exit(1);
    }

    fprintf(file, "Total Profit: %d\nTotal Weight: %d\n", total_profit, total_weight);
    fprintf(file, "Included items:\n");
    for (int i = 0; i < n_items; i++) {
        if (included_items[i]) {
            fprintf(file, "Item %d (Profit: %d, Weight: %d)\n", i + 1, items[i].profit, items[i].weight);
        }
    }

    fclose(file);
}

typedef struct {
    int level;
    int profit;
    int weight;
    float bound;
} Node;

float bound(Node node, int n, Item items[], int W) {
    int weight = node.weight;
    int profit = node.profit;
    int j;
    float bound;

    for (j = node.level + 1; j < n && weight + items[j].weight <= W; j++) {
        weight += items[j].weight;
        profit += items[j].profit;
    }

    if (j < n) {
        bound = profit + (W - weight) * (float)items[j].profit / items[j].weight;
    } else {
        bound = profit;
    }

    return bound;
}

void backtracking(int n, Item items[], int W, int *total_profit, int *total_weight, int included_items[], FILE *entries_file) {
    Node best_node;
    best_node.level = -1;
    best_node.profit = 0;
    best_node.weight = 0;
    best_node.bound = 0;

    Node current_node = best_node;

    int visit_count = 0;

    while (current_node.level < n - 1) {
        visit_count++;

        Node next_node = current_node;
        next_node.level += 1;
        next_node.weight += items[next_node.level].weight;
        next_node.profit += items[next_node.level].profit;

        if (next_node.weight <= W && next_node.profit > best_node.profit) {
            best_node = next_node;
        }

        next_node.bound = bound(next_node, n, items, W);

        if (next_node.bound > best_node.profit) {
            current_node = next_node;
            fprintf(entries_file, "%d %d %d %.2f\n", visit_count, current_node.profit, current_node.weight, current_node.bound);
        } else {
            while (current_node.level >= 0 && current_node.level < n - 1 && !(current_node.weight + items[current_node.level + 1].weight <= W)) {
                current_node.level--;
            }

            if (current_node.level < 0) {
                break;
            }

            current_node.level++;
        }
    }

    *total_profit = best_node.profit;
    *total_weight = best_node.weight;

    for (int i = 0; i < n; i++) {
        if (i <= best_node.level) {
            included_items[i] = 1;
        } else {
            included_items[i] = 0;
        }
    }
}



int main() {

    int total_profit, total_weight;
    int included_items[1000];
    // Generate and save the knapsack problem
    generate_knapsack_problem();
    save_knapsack_problem("knapsack01.txt");

    // Solve the knapsack problem using the brute force method
    brute_force_knapsack("knapsack01.txt", "output1.txt");

    dynamic_programming_refinement(n_items, items, capacity, &total_profit, &total_weight, included_items);

    save_output("output2.txt", total_profit, total_weight, included_items);

    int total_profit_bt, total_weight_bt;
    int included_items_bt[n_items];
    FILE *entries_file = fopen("entries3.txt", "w");
    backtracking(n_items, items, capacity, &total_profit_bt, &total_weight_bt, included_items_bt, entries_file);
    fclose(entries_file);
    save_output("output3.txt", total_profit_bt, total_weight_bt, included_items_bt);


    return 0;
}

